class Libromodel {
  final String title;
  final String author;
  final String genre;
  final int status;
  final String date;
  Libromodel(this.title, this.author , this.genre, this.status, this.date);
}